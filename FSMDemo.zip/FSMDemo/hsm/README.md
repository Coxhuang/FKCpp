HSM, short for Hierarchical State Machine, is an open-source C++ framework library that can be used to simplify the organization of state-driven code. The implementation is partially inspired by the UML State Machine or UML Statechart as well as by the UnrealScript State system in Unreal Engine 3.

Please visit the wiki for more information: [https://github.com/amaiorano/hsm/wiki](https://github.com/amaiorano/hsm/wiki)
