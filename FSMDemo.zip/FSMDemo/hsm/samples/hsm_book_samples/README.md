This is a collection of all sample programs from the HSM book.

To build samples:

- Install [CMake](https://cmake.org)
- Run ```cmake .```
- Now you can build the generated make file/workspace/solution depending on your target platform.
